# Clario: project rules for Claude Code

Clario is an AI decision platform (website and app): AI analyzes the options, a human expert validates, the customer decides. Tagline: Clarity for Every Choice. Clario Mind is an extension for emotional wellbeing support.

## Read first
- Design canvas: https://claude.ai/artifact/E8eDRkXP7vXFxgTFgTCHEA (about 135 screens)
- Developer Handoff: https://claude.ai/artifact/BqbW6sbDSzHPvt9bkifPYN
- Handoff Addendum (newest rules): https://claude.ai/artifact/L3XVhm12fWFV5E8M7m1nsH
- Build Plan: https://claude.ai/artifact/WKhjrAgeK1PGTukjKffc43
- designs/index.html: all 135 screens as static HTML to open in a browser (visual reference only; rebuild as real components)
- data/: design tokens (css and json), placeholder register, strings for translators

## Design rules
- Colours from data/clario-design-tokens.css. No white backgrounds: only deep teal, teal or navy.
- Fonts: Jost for headlines, DM Sans for body, Noto fonts for other scripts. Nothing under 14px. Controls at least 48px tall.
- Body text contrast 4.5:1 or better. Visible focus ring. Never rely on colour alone. Respect reduced motion.
- Layout: 12 columns desktop, 8 tablet, 4 mobile. Sidebar 264px, tablet rail 72px, mobile bottom navigation.
- Use start and end (not left and right) so Arabic works right to left.

## Product rules
- Plans: Free 5 questions a day (will be lowered later), Pro 15, Premium 25, Extra Premium unlimited with Serious Mode. Weekly, monthly or yearly billing; only the admin sets prices. Life Partner / Deep Match from Pro up.
- Only the owner account has Extra Premium free. The owner can create discount codes of any size (even 100%). Enforce this on the server only.
- Invite rule: when the 5th invited friend joins, 3 extra credits on each login day for 3 days.
- Roles: the owner is the only admin at launch and the only one who can add Moderators, Admins, Managers or Volunteers. Every privileged action goes to an audit log with a written reason.
- Nine languages: English, Bangla, Hindi, Arabic, Spanish, Japanese, Korean, German, Chinese. Keep every visible string in translation files. The entry flow must be identical in every language.
- Forum: posts and replies need admin approval. Abusive language can be banned.

## Clario Mind rules (do not weaken)
- Not a therapist, no diagnosis, never replaces qualified care. All ages by design, but each age group stays switched off until specialist sign-off, a legal check and safety tests.
- Teens: guardian consent; guardian sees only consent and urgent safety alerts. Children under 13: guardian-led, no open AI chat.
- Possible crisis: show verified emergency help first, then a trained human; never a dead end. Urgent help on every screen. Safety tools are always free; the Free chat limit (2 messages a day) is lifted in a crisis.
- Ask at the start of every session: private (removed at the end) or saved. Staff and engineers cannot read conversations. No use of Mind data for ads, matching or training.

## Working agreements
- Ask before choosing providers (hosting, payments, AI, email, SMS). Do not invent legal text, phone numbers or prices; keep the [BRACKETED] placeholders until real values are given.
- Never put passwords, keys or real personal data in code. Use environment variables.
- Write tests for every protected action, including that one customer cannot reach another's data.
