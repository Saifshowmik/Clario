# Clario designs

135 screens as standalone HTML files. Open index.html in a browser.

- They are visual references, not code to copy. Rebuild them as real components using data/clario-design-tokens.css.
- Menus, switches and forms are static. Anything in [BRACKETS] is a placeholder.
- Files named Page_xx.html are translations: bn Bangla, hi Hindi, ar Arabic (right to left), es Spanish, de German, ja Japanese, ko Korean, zh Chinese.
- Fonts load from Google Fonts, so open the files while online.
- The live canvas is the master copy: https://claude.ai/artifact/E8eDRkXP7vXFxgTFgTCHEA
