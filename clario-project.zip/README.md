# Clario: free hosting, logins, payments and admin console

The site is plain static files in `public/` (no build step). Logins, data and the admin console run on Supabase. The same code deploys to both Cloudflare Pages and GitHub Pages.

## 1. Backend (Supabase, free)
1. Create a project at supabase.com. Open **SQL Editor**, paste `supabase/schema.sql`, and run it.
2. **Authentication > Providers > Email**: keep "Confirm email" turned on.
3. **Project Settings > API**: copy the Project URL and the `anon` key into `public/config.js`. Also set `wallet` to your bKash/Nagad number. Never use the `service_role` key anywhere in the site.

## 2. Host (free)
1. Push this folder to a new GitHub repository (branch `main`).
2. **Cloudflare Pages**: Workers & Pages > Create > Pages > Connect to Git > pick the repo. Build command: leave empty. Build output directory: `public`.
3. **GitHub Pages**: repo Settings > Pages > Source: **GitHub Actions**. The included workflow deploys `public/` on every push.
4. Back in Supabase, **Authentication > URL Configuration**: set the Site URL to your main address and add both site addresses (Cloudflare and GitHub Pages) under Redirect URLs, or confirmation and reset emails will not return to the site.

## 3. Become the owner
Sign up on the live site, confirm your email, then run this once in the SQL Editor:
`update public.profiles set role = 'owner' where email = 'YOUR-EMAIL@example.com';`
An **Admin** link then appears in the footer. Only the owner can set prices, review payments and change plans, and each action needs a written reason that goes to the audit log. These rules are enforced by the database.

## 4. How payments work now
A customer sends money to your bKash or Nagad number, then enters the transaction ID on the Plans page. You see it under Admin > Pending payments and approve it, and their plan changes. Set prices in the Admin console first; until then the site shows `[PRICE]`.

## Not included yet
- Admin 2-step verification (Supabase supports authenticator-app MFA; turn it on before real use).
- Plan expiry: approved plans stay until you change them under Users and plans.
- Account deletion, a payment gateway, the other seven languages, the forum, and Clario Mind.
- Real legal text, your story and contact details: the `[BRACKETED]` placeholders are still in place.
- New screens are in English and Bangla except the owner-only Admin console, which is English only.
- Check Supabase's current limits before launch: free projects pause after inactivity, and its built-in email sending is limited, so plan to add your own email provider.
- This has not been tested against a live Supabase project, so run through sign-up, a decision, a payment request and an approval once before sharing it.
