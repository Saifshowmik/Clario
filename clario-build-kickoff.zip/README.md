# Clario build kickoff

1. Install Claude Code and open a new empty folder for the project.
2. Copy this pack's files into it (CLAUDE.md at the top, data/ beside it).
3. Paste the first prompt below.

## Prompt 1: plan and decisions
"Read CLAUDE.md and the four documents it links. Do not write code yet. List the decisions we need to make (stack, hosting country, database, login, payments, AI provider, email and SMS), give two options each with pros and cons for a small team, and recommend one. Wait for my answers."

## Prompt 2: foundations
"Using the stack we chose, create the repository structure, environments (development, staging, production), an automatic test and deploy pipeline, and a coded design system from data/clario-design-tokens.css. Add a translation framework that reads strings from files, with English first and right-to-left support."

## Prompt 3: first features (Phase 1)
"Build registration and login with email verification and password reset, roles, the separate admin sign-in with 2-step verification, and My Profiles with the onboarding quiz. Add tests, including that one customer cannot see another's data. Show me each screen before moving on."

Phases after that are in the Build Plan. Clario Mind comes last and only after its safety gates.
