// Supabase project for Clario. The anon key is public by design (row-level security protects the data).
// NEVER put the service_role key here.
window.CLARIO={url:"https://tgpzzezqneztkzjcgwep.supabase.co",key:"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRncHp6ZXpxbmV6dGt6amNnd2VwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTI1NjYyODksImV4cCI6MjEwODE0MjI4OX0.JxhPQqY_-ichF3YKI3W7tW-0frczxyMSg3GEqycPXxI",wallet:"[WALLET NUMBER]"};
